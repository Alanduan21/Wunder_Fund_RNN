import numpy as np
from utils import DataPoint
import torch
from GRU_model import GRUModel

class PredictionModel:
    def __init__(self):
        # Initialize your model, load weights, etc.
        
        # Load scaler
        scaler = torch.load("scaler.pt", map_location="cpu")
        self.mean = scaler["mean"].values.astype(np.float32)
        self.std = scaler["std"].values.astype(np.float32)

        # Load model
        
        input_size = len(self.mean)  # should be 35
        self.model = GRUModel(input_size=input_size, hidden_size=64, num_layers=2)
        self.model.load_state_dict(torch.load("gru_model.pth", map_location="cpu", weights_only=True))
        self.model.eval()

        # Sequence buffer per seq_ix
        self.buffers = {}
        self.seq_len = 50


    def normalize(self, state: np.ndarray) -> np.ndarray:
        return (state - self.mean) / self.std

    def denormalize_target(self, value: float) -> float:
        return value * self.std[0] + self.mean[0]

    def predict(self, data_point: DataPoint) -> np.ndarray | None:
        # This is where your prediction logic goes.



        if not data_point.need_prediction:
            return None
        
        seq_id = data_point.seq_ix
        if seq_id not in self.buffers:
            self.buffers[seq_id] = []
        
        
        # Add normalized state to buffer
        self.buffers[seq_id].append(self.normalize(data_point.state))
        if len(self.buffers[seq_id]) > self.seq_len:
            self.buffers[seq_id] = self.buffers[seq_id][-self.seq_len:]


        # Prepare input tensor
        seq_array = np.array(self.buffers[seq_id], dtype=np.float32)
        seq_array = np.expand_dims(seq_array, axis=0)  # (1, T, features)
        seq_tensor = torch.from_numpy(seq_array)


        # Predict target feature
        with torch.no_grad():
            out = self.model(seq_tensor).item()  # scalar prediction

        # Build full prediction vector
        prediction = np.copy(data_point.state)  # start from last known state
        prediction[0] = self.denormalize_target(out)  # replace target feature

        return prediction
